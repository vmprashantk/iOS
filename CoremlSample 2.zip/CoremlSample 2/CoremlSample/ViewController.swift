//
//  ViewController.swift
//  CoremlSample
//
//  Created by Prashant on 23/02/18.
//  Copyright © 2018 DivySoft. All rights reserved.
//

import UIKit
import AVKit
import Vision
class ViewController: UIViewController,AVCaptureVideoDataOutputSampleBufferDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
       let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        guard  let capture = AVCaptureDevice.default(for: .video) else {
            return
        }
        
    
        guard let input = try? AVCaptureDeviceInput(device: capture) else{
            return
        }
        captureSession.addInput(input)
        captureSession.startRunning()
        
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer)
        previewLayer.frame = view.frame
        
        
        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label:"videoqueue"))
        captureSession.addOutput(dataOutput)
        //VNImageRequestHandler(cgImage: [<#T##CGImage#>], options: [:])
    }

    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        guard  let pixelBuffer =    CMSampleBufferGetImageBuffer(sampleBuffer) else{
            return
        }
        

        guard let model = try? VNCoreMLModel(for: Resnet50().model) else{return}
        let request = VNCoreMLRequest(model: model) { (finishRequest, error) in
            
            
            guard let results = finishRequest.results as? [VNClassificationObservation] else {return}
            
            guard let firstObservation = results.first else{
                return
            }
            
            print(firstObservation.identifier,firstObservation.confidence)
            
        }
        try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

